from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

def index(request):
    return render(request, 'index.html')


from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt  # Optional, if you want to disable CSRF for testing
def submit_form(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')

        # Save the input to a text file
        with open('contact_form.txt', 'a') as f:
            f.write(f'Name: {name}\nEmail: {email}\nSubject: {subject}\nMessage: {message}\n\n')

        return redirect('success')  # Redirect to a success page or back to the form

    return HttpResponse('Invalid request', status=400)
