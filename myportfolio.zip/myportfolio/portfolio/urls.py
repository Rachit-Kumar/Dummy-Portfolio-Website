# portfolio/urls.py
from django.urls import path
from . import views
from django.views.generic import TemplateView  # Make sure this is imported

from .views import submit_form

urlpatterns = [
    path('', views.index, name='index'),
    
    path('submit_form/', submit_form, name='submit_form'),
    path('success/', TemplateView.as_view(template_name='success.html'), name='success'),  # Ensure this line is correct
]
